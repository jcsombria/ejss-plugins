This output folder is where EJS locates intermediate files it uses when running.
You can, however, administer its contents as you wish. For instance, by cleaning it from time to time.
This export folder is where EJS locates your packaged simulations, by default.
You can administer its contents as you wish.